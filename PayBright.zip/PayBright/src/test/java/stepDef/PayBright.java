package stepDef;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pageActions.CommonAction;
import pageActions.PayBrightAction;
import utils.ConfigFileReader;
import utils.SeleniumDriver;

public class PayBright {

	final Log log = LogFactory.getLog(PayBright.class.getName());
	ConfigFileReader configFileReader;
	PayBrightAction PayBrightActions = new PayBrightAction();
	
public PayBright() {
		
	}
@Given("^Open up a browser window and navigate to \"([^\"]*)\"$")
public void open_up_a_browser_window_and_navigate_to(String URL) throws Throwable {
	SeleniumDriver.openPage(URL);
    
}

@When("^In the search bar enter \"([^\"]*)\" and click on the Google Search button$")
public void in_the_search_bar_enter_and_click_on_the_Google_Search_button(String Search) throws Throwable {
	PayBrightActions.Entersearchbar(Search);
}

@When("^Verify that paybright is present on screen$")
public void verify_that_paybright_is_present_on_screen() throws Throwable {
	PayBrightActions.VerifyPayBrightWebSite();
}

@When("^Navigate to PayBright website and verify that the PayBright website is loaded$")
public void navigate_to_PayBright_website_and_verify_that_the_PayBright_website_is_loaded() throws Throwable {
	PayBrightActions.NaviagtePayBrightWebSite();
}

@When("^Navigate to Shop Directory$")
public void navigate_to_Shop_Directory() throws Throwable {
	PayBrightActions.NaviagteToShopDirectory();
}
@When("^Choose \"([^\"]*)\" in the Sort By drop down box and enter \"([^\"]*)\" in the search box$")
public void choose_in_the_Sort_By_drop_down_box_and_enter_in_the_search_box(String SortBy, String MerchantName) throws Throwable {
	PayBrightActions.SearchingMerchant(SortBy, MerchantName);
}

@Then("^Verify that ‘Samsung’ is present in the search results$")
public void verify_that_Samsung_is_present_in_the_search_results() throws Throwable {
	PayBrightActions.VerifyingSearchingresult();
}
}
